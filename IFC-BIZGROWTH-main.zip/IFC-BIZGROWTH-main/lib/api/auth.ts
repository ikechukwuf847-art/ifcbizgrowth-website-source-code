const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL;
const SUPABASE_ANON_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

if (!SUPABASE_URL) {
  throw new Error("Missing NEXT_PUBLIC_SUPABASE_URL");
}

if (!SUPABASE_ANON_KEY) {
  throw new Error("Missing NEXT_PUBLIC_SUPABASE_ANON_KEY");
}

/*
 * These constants are explicitly typed as strings so TypeScript
 * knows they are definitely available inside our functions.
 */
const supabaseUrl: string = SUPABASE_URL;
const supabaseAnonKey: string = SUPABASE_ANON_KEY;

const FUNCTIONS_URL = `${supabaseUrl}/functions/v1`;

type ApiResponse<T = unknown> = {
  success: boolean;
  message?: string;
  error?: string;
  code?: string;
  [key: string]: unknown;
};

async function callFunction<T extends ApiResponse>(
  functionName: string,
  body: Record<string, unknown>,
): Promise<T> {
  const response = await fetch(`${FUNCTIONS_URL}/${functionName}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      apikey: supabaseAnonKey,
      Authorization: `Bearer ${supabaseAnonKey}`,
    },
    body: JSON.stringify(body),
  });

  let data: T;

  try {
    data = await response.json();
  } catch {
    throw new Error("The server returned an invalid response.");
  }

  if (!response.ok || !data.success) {
    const error = new Error(
      data.error || "Something went wrong. Please try again.",
    ) as Error & {
      status?: number;
      code?: string;
      data?: T;
    };

    error.status = response.status;
    error.code = data.code;
    error.data = data;

    throw error;
  }

  return data;
}

/* =========================================
   SIGNUP
========================================= */

export type SignupResponse = {
  success: boolean;
  message: string;
  user_id: string;
  email: string;
  expires_in_seconds: number;
};

export async function signup(email: string, password: string) {
  return callFunction<SignupResponse>("signup", {
    email,
    password,
  });
}

/* =========================================
   VERIFY OTP
========================================= */

export type VerifyOtpResponse = {
  success: boolean;
  message: string;
  user_id: string;
  email: string;
};

export async function verifyOtp(email: string, otp: string) {
  return callFunction<VerifyOtpResponse>("verify-otp", {
    email,
    otp,
  });
}

/* =========================================
   RESEND OTP
========================================= */

export type ResendOtpResponse = {
  success: boolean;
  message: string;
  expires_in_seconds?: number;
  retry_after_seconds?: number;
};

export async function resendOtp(email: string) {
  return callFunction<ResendOtpResponse>("resend-otp", {
    email,
  });
}

/* =========================================
   LOGIN
========================================= */

export type LoginResponse = {
  success: boolean;
  message: string;

  user: {
    id: string;
    email: string;
  };

  session: {
    access_token: string;
    refresh_token: string;
    expires_at: number | null;
    expires_in: number;
    token_type: string;
  };
};

export async function login(email: string, password: string) {
  return callFunction<LoginResponse>("login", {
    email,
    password,
  });
}

/* =========================================
   FORGOT PASSWORD
========================================= */

export type ForgotPasswordResponse = {
  success: boolean;
  message: string;
  expires_in_seconds?: number;
  retry_after_seconds?: number;
};

export async function forgotPassword(email: string) {
  return callFunction<ForgotPasswordResponse>("forgot-password", {
    email,
  });
}

/* =========================================
   RESET PASSWORD
========================================= */

export type ResetPasswordResponse = {
  success: boolean;
  message: string;
};

export async function resetPassword(
  email: string,
  otp: string,
  newPassword: string,
) {
  return callFunction<ResetPasswordResponse>("reset-password", {
    email,
    otp,
    new_password: newPassword,
  });
      }
