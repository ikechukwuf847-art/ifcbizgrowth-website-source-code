"use client";

import {
  ChangeEvent,
  FormEvent,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import { createSupabaseBrowserClient } from "@/lib/supabase/browser";
import "./business-profile.css";

type Business = {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  email: string | null;
  phone: string | null;
  website_url: string | null;
  logo_url: string | null;
  country_code: string | null;
  verification_status: string | null;
  is_featured: boolean;
  is_public: boolean;
  status: string;
};

type Location = {
  id: string;
  business_id: string;
  country_code: string | null;
  city: string | null;
  state_region: string | null;
  address: string | null;
  address_line_1: string | null;
  address_line_2: string | null;
  postal_code: string | null;
  latitude: number | null;
  longitude: number | null;
  is_primary: boolean;
  is_active: boolean;
  is_public: boolean;
};

type Review = {
  id: string;
  business_id: string;
  reviewer_id: string | null;
  reviewer_name: string | null;
  reviewer_avatar_url: string | null;
  rating: number;
  review_text: string | null;
  is_published: boolean;
  created_at: string;
};

type Rating = {
  average_rating: number | null;
  review_count: number | null;
};

type GenericRow = Record<string, unknown>;

type ProfileSection =
  | "about"
  | "products"
  | "services"
  | "promotions"
  | "photos"
  | "contact"
  | "hours"
  | "social"
  | "reviews";

const SUPABASE_URL =
  "https://iluczxsqdpohzgbknldh.supabase.co";

/*
 * ANALYTICS HELPERS
 *
 * Uses the existing /api/analytics/business endpoint.
 * Analytics failures must never interrupt profile functionality.
 */

type AnalyticsMetadata = Record<
  string,
  string | number | boolean | null
>;

function getAnalyticsId(storage: Storage, key: string) {
  try {
    let id = storage.getItem(key);

    if (!id) {
      id =
        typeof crypto !== "undefined" &&
        typeof crypto.randomUUID === "function"
          ? crypto.randomUUID()
          : `${Date.now()}-${Math.random()
              .toString(36)
              .slice(2)}`;

      storage.setItem(key, id);
    }

    return id;
  } catch {
    return `${Date.now()}-${Math.random()
      .toString(36)
      .slice(2)}`;
  }
}

function isValidUrl(value: string | null | undefined) {
  if (!value) return false;

  try {
    new URL(value);
    return true;
  } catch {
    return false;
  }
}

function getStorageUrl(
  bucket: string,
  path: string | null,
) {
  if (!path) return null;

  if (isValidUrl(path)) {
    return path;
  }

  const cleanPath = path
    .replace(/^\/+/, "")
    .replace(new RegExp(`^${bucket}/`), "");

  return `${SUPABASE_URL}/storage/v1/object/public/${bucket}/${cleanPath}`;
}

function getLogoUrl(path: string | null) {
  return getStorageUrl("business-logos", path);
}

function getCustomerAvatarUrl(path: string | null) {
  return getStorageUrl("customer-logo", path);
}

/*
 * SERVICES, PROMOTIONS AND BUSINESS PHOTOS
 * all use business-media.
 */
function getBusinessMediaUrl(path: string | null) {
  return getStorageUrl("business-media", path);
}

/*
 * PRODUCTS use product-media.
 */
function getProductMediaUrl(path: string | null) {
  return getStorageUrl("product-media", path);
}

function getInitials(name: string) {
  return name
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((part) => part.charAt(0).toUpperCase())
    .join("");
}

function cleanPhone(phone: string) {
  return phone.replace(/[^\d+]/g, "");
}

function getWhatsAppUrl(
  phone: string | null,
  businessName: string,
) {
  if (!phone) return null;

  const digits = cleanPhone(phone).replace(/^\+/, "");

  if (!digits) return null;

  return `https://wa.me/${digits}?text=${encodeURIComponent(
    `Hello ${businessName}, I found your business on IFC BIZGROWTH.`,
  )}`;
}

function getRowText(
  row: GenericRow,
  keys: string[],
): string | null {
  for (const key of keys) {
    const value = row[key];

    if (
      typeof value === "string" &&
      value.trim().length > 0
    ) {
      return value.trim();
    }

    if (
      typeof value === "number" ||
      typeof value === "boolean"
    ) {
      return String(value);
    }
  }

  return null;
}

function getMediaPath(row: GenericRow) {
  return getRowText(row, [
    "storage_path",
    "image_path",
    "image_url",
    "media_url",
    "media_path",
    "photo_url",
    "photo_path",
    "thumbnail_url",
    "thumbnail_path",
    "url",
    "image",
  ]);
}

function getDayName(value: unknown) {
  const day = Number(value);

  const days = [
    "Sunday",
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday",
  ];

  if (
    Number.isInteger(day) &&
    day >= 0 &&
    day <= 6
  ) {
    return days[day];
  }

  return typeof value === "string" ? value : "";
}

function formatBusinessTime(value: string | null) {
  if (!value) return null;

  const parts = value.split(":");
  const hour = Number(parts[0]);
  const minute = Number(parts[1] || 0);

  if (
    Number.isNaN(hour) ||
    Number.isNaN(minute)
  ) {
    return value;
  }

  const suffix = hour >= 12 ? "PM" : "AM";
  const displayHour = hour % 12 || 12;

  return `${displayHour}:${String(minute).padStart(
    2,
    "0",
  )} ${suffix}`;
}

function isBusinessVerified(status: string | null) {
  if (!status) return false;

  const normalized = status
    .trim()
    .toLowerCase()
    .replace(/[\s-]+/g, "_");

  return [
    "verified",
    "approved",
    "fully_verified",
    "verified_business",
  ].includes(normalized);
}

function formatDate(value: string) {
  try {
    return new Intl.DateTimeFormat("en", {
      day: "numeric",
      month: "short",
      year: "numeric",
    }).format(new Date(value));
  } catch {
    return "";
  }
}

function StarRating({
  rating,
  size = "medium",
}: {
  rating: number;
  size?: "small" | "medium" | "large";
}) {
  const rounded = Math.round(rating);

  return (
    <div
      className={`bp-stars bp-stars-${size}`}
      aria-label={`${rating.toFixed(1)} out of 5 stars`}
    >
      {[1, 2, 3, 4, 5].map((star) => (
        <span
          key={star}
          className={star <= rounded ? "filled" : ""}
        >
          ★
        </span>
      ))}
    </div>
  );
}

function Logo({
  src,
  name,
}: {
  src: string | null;
  name: string;
}) {
  const [failed, setFailed] = useState(false);

  if (!src || failed) {
    return (
      <div className="bp-logo-fallback">
        {getInitials(name)}
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={`${name} logo`}
      className="bp-logo-image"
      onError={() => setFailed(true)}
    />
  );
}

export default function BusinessProfilePage() {
  const params = useParams();

  const slug =
    typeof params.slug === "string"
      ? params.slug
      : "";

  const supabase = useMemo(
    () => createSupabaseBrowserClient(),
    [],
  );

  const [business, setBusiness] =
    useState<Business | null>(null);

  const [location, setLocation] =
    useState<Location | null>(null);

  const [reviews, setReviews] =
    useState<Review[]>([]);

  const [rating, setRating] =
    useState<Rating>({
      average_rating: null,
      review_count: 0,
    });

  const [products, setProducts] =
    useState<GenericRow[]>([]);

  const [services, setServices] =
    useState<GenericRow[]>([]);

  const [media, setMedia] =
    useState<GenericRow[]>([]);

  const [socialLinks, setSocialLinks] =
    useState<GenericRow[]>([]);

  const [promotions, setPromotions] =
    useState<GenericRow[]>([]);

  const [hours, setHours] =
    useState<GenericRow[]>([]);

  const [loading, setLoading] = useState(true);

  const [notFound, setNotFound] =
    useState(false);

  const [error, setError] = useState("");

  const [showShare, setShowShare] =
    useState(false);

  const [copied, setCopied] = useState(false);

  const [reviewerName, setReviewerName] =
    useState("");

  const [reviewText, setReviewText] =
    useState("");

  const [reviewRating, setReviewRating] =
    useState(0);

  const [reviewImage, setReviewImage] =
    useState<File | null>(null);

  const [
    reviewImagePreview,
    setReviewImagePreview,
  ] = useState<string | null>(null);

  const [
    submittingReview,
    setSubmittingReview,
  ] = useState(false);

  const [
    reviewMessage,
    setReviewMessage,
  ] = useState("");

  /*
   * Controls which profile section is displayed.
   */
  const [activeSection, setActiveSection] =
    useState<ProfileSection>("about");

  /*
   * Prevent repeated profile-view tracking during
   * this component's lifetime.
   */
  const trackedProfileViews = useRef<Set<string>>(
    new Set(),
  );

  /*
   * Prevent duplicate location-view tracking when
   * React reruns an effect for the same location.
   */
  const trackedLocationViews = useRef<Set<string>>(
    new Set(),
  );

  /*
   * Send analytics to the existing API endpoint.
   * Errors never interrupt normal functionality.
   */
  const trackEvent = useCallback(
    async (
      businessId: string,
      eventType: string,
      metadata: AnalyticsMetadata = {},
    ) => {
      if (
        typeof window === "undefined" ||
        !businessId
      ) {
        return;
      }

      try {
        const visitorId = getAnalyticsId(
          window.localStorage,
          "ifc_bizgrowth_visitor_id",
        );

        const sessionId = getAnalyticsId(
          window.sessionStorage,
          "ifc_bizgrowth_session_id",
        );

        await fetch("/api/analytics/business", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          keepalive: true,
          body: JSON.stringify({
            business_id: businessId,
            event_type: eventType,
            visitor_id: visitorId,
            session_id: sessionId,
            metadata: {
              ...metadata,
              page_path: window.location.pathname,
              page_url: window.location.href,
            },
          }),
        });
      } catch {
        // Analytics must never interrupt functionality.
      }
    },
    [],
  );

  const loadBusiness = useCallback(async () => {
    if (!slug) return;

    setLoading(true);
    setError("");
    setNotFound(false);

    try {
      const {
        data: businessData,
        error: businessError,
      } = await supabase
        .from("businesses")
        .select(
          `
            id,
            name,
            slug,
            description,
            email,
            phone,
            website_url,
            logo_url,
            country_code,
            verification_status,
            is_featured,
            is_public,
            status
          `,
        )
        .eq("slug", slug)
        .eq("is_public", true)
        .eq("status", "active")
        .maybeSingle();

      if (businessError) {
        throw businessError;
      }

      if (!businessData) {
        setNotFound(true);
        setBusiness(null);
        return;
      }

      setBusiness(businessData as Business);

      const businessId = businessData.id;

      /*
       * ANALYTICS: Record a profile view.
       */
      if (
        !trackedProfileViews.current.has(businessId)
      ) {
        trackedProfileViews.current.add(businessId);

        void trackEvent(
          businessId,
          "profile_view",
          {
            business_slug: businessData.slug,
            business_name: businessData.name,
            source: document.referrer
              ? "external_or_previous_page"
              : "direct",
          },
        );
      }

      const [
        locationResult,
        reviewsResult,
        ratingResult,
        productsResult,
        servicesResult,
        mediaResult,
        socialResult,
        promotionsResult,
        hoursResult,
      ] = await Promise.all([
        supabase
          .from("business_locations")
          .select("*")
          .eq("business_id", businessId)
          .eq("is_active", true)
          .eq("is_public", true)
          .order("is_primary", {
            ascending: false,
          })
          .limit(1)
          .maybeSingle(),

        supabase
          .from("business_reviews")
          .select("*")
          .eq("business_id", businessId)
          .eq("is_published", true)
          .order("created_at", {
            ascending: false,
          }),

        supabase.rpc("get_business_rating", {
          p_business_id: businessId,
        }),

        supabase
          .from("business_products")
          .select("*")
          .eq("business_id", businessId),

        supabase
          .from("business_services")
          .select("*")
          .eq("business_id", businessId),

        supabase
          .from("business_media")
          .select("*")
          .eq("business_id", businessId)
          .eq("is_active", true)
          .order("sort_order", {
            ascending: true,
          }),

        supabase
          .from("business_social_links")
          .select("*")
          .eq("business_id", businessId),

        supabase
          .from("business_promotions")
          .select("*")
          .eq("business_id", businessId),

        supabase
          .from("business_hours")
          .select("*")
          .eq("business_id", businessId)
          .order("day_of_week", {
            ascending: true,
          }),
      ]);

      if (locationResult.error) {
        console.error(locationResult.error);
      }

      if (reviewsResult.error) {
        console.error(reviewsResult.error);
      }

      if (productsResult.error) {
        console.error(productsResult.error);
      }

      if (servicesResult.error) {
        console.error(servicesResult.error);
      }

      if (mediaResult.error) {
        console.error(mediaResult.error);
      }

      if (socialResult.error) {
        console.error(socialResult.error);
      }

      if (promotionsResult.error) {
        console.error(promotionsResult.error);
      }

      if (hoursResult.error) {
        console.error(hoursResult.error);
      }

      setLocation(
        (locationResult.data as Location | null) ?? null,
      );

      setReviews(
        (reviewsResult.data as Review[]) ?? [],
      );

      const ratingData = Array.isArray(ratingResult.data)
        ? ratingResult.data[0]
        : ratingResult.data;

      if (ratingData) {
        setRating({
          average_rating:
            Number(ratingData.average_rating) || 0,
          review_count:
            Number(ratingData.review_count) || 0,
        });
      } else {
        setRating({
          average_rating: 0,
          review_count: 0,
        });
      }

      setProducts(
        (productsResult.data as GenericRow[]) ?? [],
      );

      setServices(
        (servicesResult.data as GenericRow[]) ?? [],
      );

      setMedia(
        (mediaResult.data as GenericRow[]) ?? [],
      );

      setSocialLinks(
        (socialResult.data as GenericRow[]) ?? [],
      );

      setPromotions(
        (promotionsResult.data as GenericRow[]) ?? [],
      );

      setHours(
        (hoursResult.data as GenericRow[]) ?? [],
      );
    } catch (err) {
      console.error(err);

      setError(
        "We couldn't load this business right now. Please try again.",
      );
    } finally {
      setLoading(false);
    }
  }, [slug, supabase, trackEvent]);

  useEffect(() => {
    void loadBusiness();
  }, [loadBusiness]);

  useEffect(() => {
    return () => {
      if (reviewImagePreview) {
        URL.revokeObjectURL(reviewImagePreview);
      }
    };
  }, [reviewImagePreview]);

  /*
   * Start on About when the slug changes.
   */
  useEffect(() => {
    setActiveSection("about");
  }, [slug]);

  /*
   * ANALYTICS: Track profile-section visits.
   */
  useEffect(() => {
    if (!business?.id) return;

    void trackEvent(business.id, "section_view", {
      section: activeSection,
    });
  }, [business?.id, activeSection, trackEvent]);

  const logoUrl = getLogoUrl(
    business?.logo_url ?? null,
  );

  const whatsappUrl = getWhatsAppUrl(
    business?.phone ?? null,
    business?.name ?? "",
  );

  const address = useMemo(() => {
    if (!location) return "";

    return [
      location.address_line_1,
      location.address_line_2,
      location.address,
      location.city,
      location.state_region,
      location.country_code,
    ]
      .filter(Boolean)
      .join(", ");
  }, [location]);

  const mapUrl = useMemo(() => {
    if (!location) return null;

    if (
      typeof location.latitude === "number" &&
      typeof location.longitude === "number"
    ) {
      return `https://www.google.com/maps/dir/?api=1&destination=${location.latitude},${location.longitude}`;
    }

    if (address) {
      return `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(
        address,
      )}`;
    }

    return null;
  }, [location, address]);

  /*
   * ANALYTICS: Track product, service, and promotion
   * section visits using dashboard event names.
   */
  useEffect(() => {
    if (!business?.id) return;

    const eventTypes: Partial<
      Record<ProfileSection, string>
    > = {
      products: "product_view",
      services: "service_view",
      promotions: "promotion_view",
    };

    const eventType = eventTypes[activeSection];

    if (!eventType) return;

    void trackEvent(business.id, eventType, {
      section: activeSection,
      business_slug: business.slug,
    });
  }, [
    business?.id,
    business?.slug,
    activeSection,
    trackEvent,
  ]);

  /*
   * ANALYTICS: Track visits to the contact section
   * when a public address or map destination exists.
   */
  useEffect(() => {
    if (
      !business?.id ||
      activeSection !== "contact"
    ) {
      return;
    }

    if (!address && !mapUrl) return;

    const trackingKey =
      `${business.id}:${address}:${mapUrl}`;

    if (
      trackedLocationViews.current.has(trackingKey)
    ) {
      return;
    }

    trackedLocationViews.current.add(trackingKey);

    void trackEvent(business.id, "location_view", {
      has_location: Boolean(
        location?.latitude != null &&
          location?.longitude != null,
      ),
      has_address: Boolean(address),
    });
  }, [
    business?.id,
    activeSection,
    address,
    mapUrl,
    location?.latitude,
    location?.longitude,
    trackEvent,
  ]);

  const pageUrl =
    typeof window !== "undefined"
      ? window.location.href
      : "";

  const encodedPageUrl = encodeURIComponent(pageUrl);

  const encodedShareText = encodeURIComponent(
    business
      ? `Check out ${business.name} on IFC BIZGROWTH.`
      : "Check out this business on IFC BIZGROWTH.",
  );

  const shareBusiness = async () => {
    if (!business) return;

    void trackEvent(business.id, "share_click", {
      method: "native_or_share_menu",
    });

    const shareData = {
      title: business.name,
      text:
        business.description ||
        `Check out ${business.name} on IFC BIZGROWTH.`,
      url: pageUrl,
    };

    try {
      if (
        typeof navigator !== "undefined" &&
        navigator.share
      ) {
        await navigator.share(shareData);
        return;
      }

      setShowShare(true);
    } catch {
      // User cancelled sharing.
    }
  };

  const copyLink = async () => {
    try {
      await navigator.clipboard.writeText(pageUrl);

      if (business) {
        void trackEvent(business.id, "share_click", {
          method: "copy_link",
        });
      }

      setCopied(true);

      window.setTimeout(() => {
        setCopied(false);
      }, 2000);
    } catch {
      setError("Unable to copy the business link.");
    }
  };

  const shareToTikTok = async () => {
    if (business) {
      void trackEvent(business.id, "share_click", {
        method: "tiktok",
      });
    }

    try {
      await navigator.clipboard.writeText(pageUrl);

      setCopied(true);

      window.setTimeout(() => {
        setCopied(false);
      }, 2000);

      window.open(
        "https://www.tiktok.com/",
        "_blank",
        "noopener,noreferrer",
      );
    } catch {
      window.open(
        "https://www.tiktok.com/",
        "_blank",
        "noopener,noreferrer",
      );
    }
  };

  const handleReviewImage = (
    event: ChangeEvent<HTMLInputElement>,
  ) => {
    const file = event.target.files?.[0];

    if (!file) return;

    const allowed = [
      "image/jpeg",
      "image/png",
      "image/webp",
    ];

    if (!allowed.includes(file.type)) {
      setReviewMessage(
        "Please choose a JPG, PNG, or WebP image.",
      );

      event.target.value = "";
      return;
    }

    if (file.size > 2 * 1024 * 1024) {
      setReviewMessage(
        "Your picture must be 2 MB or smaller.",
      );

      event.target.value = "";
      return;
    }

    if (reviewImagePreview) {
      URL.revokeObjectURL(reviewImagePreview);
    }

    setReviewImage(file);
    setReviewMessage("");

    const previewUrl = URL.createObjectURL(file);

    setReviewImagePreview(previewUrl);
  };

  const submitReview = async (
    event: FormEvent<HTMLFormElement>,
  ) => {
    event.preventDefault();

    if (!business) return;

    setReviewMessage("");

    if (reviewerName.trim().length < 2) {
      setReviewMessage("Please enter your name.");
      return;
    }

    if (!reviewRating) {
      setReviewMessage("Please select a rating.");
      return;
    }

    setSubmittingReview(true);

    try {
      let avatarPath: string | null = null;

      if (reviewImage) {
        const extension =
          reviewImage.name
            .split(".")
            .pop()
            ?.toLowerCase() || "jpg";

        const randomPart = crypto.randomUUID();

        const filePath =
          `reviews/${business.id}/${randomPart}.${extension}`;

        const { error: uploadError } =
          await supabase.storage
            .from("customer-logo")
            .upload(filePath, reviewImage, {
              cacheControl: "3600",
              upsert: false,
              contentType: reviewImage.type,
            });

        if (uploadError) {
          throw uploadError;
        }

        avatarPath = filePath;
      }

      const { error: reviewError } =
        await supabase.rpc(
          "submit_public_business_review",
          {
            p_business_id: business.id,
            p_reviewer_name: reviewerName.trim(),
            p_reviewer_avatar_url: avatarPath,
            p_rating: reviewRating,
            p_review_text: reviewText.trim() || null,
          },
        );

      if (reviewError) {
        throw reviewError;
      }

      /*
       * ANALYTICS: Track successful submissions only.
       * Never send the reviewer's name or review text.
       */
      void trackEvent(
        business.id,
        "review_submitted",
        {
          rating: reviewRating,
          included_text: reviewText.trim().length > 0,
          included_image: Boolean(reviewImage),
        },
      );

      setReviewerName("");
      setReviewText("");
      setReviewRating(0);
      setReviewImage(null);

      if (reviewImagePreview) {
        URL.revokeObjectURL(reviewImagePreview);
      }

      setReviewImagePreview(null);

      setReviewMessage(
        "Thank you! Your review has been submitted.",
      );

      setActiveSection("reviews");

      await loadBusiness();
    } catch (err) {
      console.error(err);

      setReviewMessage(
        "We couldn't submit your review. Please try again.",
      );
    } finally {
      setSubmittingReview(false);
    }
  };

  /*
   * Navigation configuration.
   * Only sections containing data are shown,
   * except About and Reviews.
   */
  const navigationItems = useMemo(() => {
    const items: {
      id: ProfileSection;
      label: string;
      count?: number;
    }[] = [];

    items.push({
      id: "about",
      label: "About",
    });

    if (products.length > 0) {
      items.push({
        id: "products",
        label: "Products",
        count: products.length,
      });
    }

    if (services.length > 0) {
      items.push({
        id: "services",
        label: "Services",
        count: services.length,
      });
    }

    if (promotions.length > 0) {
      items.push({
        id: "promotions",
        label: "Promotions",
        count: promotions.length,
      });
    }

    if (media.length > 0) {
      items.push({
        id: "photos",
        label: "Photos",
        count: media.length,
      });
    }

    if (
      address ||
      business?.phone ||
      business?.email ||
      business?.website_url
    ) {
      items.push({
        id: "contact",
        label: "Contact",
      });
    }

    if (hours.length > 0) {
      items.push({
        id: "hours",
        label: "Hours",
      });
    }

    if (socialLinks.length > 0) {
      items.push({
        id: "social",
        label: "Social",
      });
    }

    items.push({
      id: "reviews",
      label: "Reviews",
      count: rating.review_count || 0,
    });

    return items;
  }, [
    products.length,
    services.length,
    promotions.length,
    media.length,
    address,
    business?.phone,
    business?.email,
    business?.website_url,
    hours.length,
    socialLinks.length,
    rating.review_count,
  ]);

  if (loading) {
    return (
      <main className="bp-page">
        <div className="bp-loading">
          <div className="bp-spinner" />
          <p>Loading business...</p>
        </div>
      </main>
    );
  }

  if (notFound || !business) {
    return (
      <main className="bp-page">
        <div className="bp-empty">
          <div className="bp-empty-icon">?</div>

          <h1>Business not found</h1>

          <p>
            This business may no longer be publicly
            available.
          </p>

          <Link
            href="/businesses"
            className="bp-primary-button"
          >
            Browse businesses
          </Link>
        </div>
      </main>
    );
  }

  return (
    <main className="bp-page">
      <header className="bp-topbar">
        <div className="bp-topbar-inner">
          <Link
            href="/businesses"
            className="bp-back"
            aria-label="Back to businesses"
          >
            ←
          </Link>

          <Link
            href="/discover"
            className="bp-brand"
          >
            IFC BIZGROWTH
          </Link>

          <button
            type="button"
            className="bp-share-top"
            onClick={() => {
              void trackEvent(
                business.id,
                "share_menu_open",
              );

              setShowShare((value) => !value);
            }}
            aria-label="Share business"
          >
            ↗
          </button>
        </div>

        {showShare && (
          <div className="bp-share-menu">
            <div className="bp-share-title">
              <strong>Share business</strong>

              <button
                type="button"
                onClick={() => setShowShare(false)}
                aria-label="Close share menu"
              >
                ×
              </button>
            </div>

            <div className="bp-share-grid">
              <a
                href={
                  whatsappUrl ||
                  `https://wa.me/?text=${encodedShareText}%20${encodedPageUrl}`
                }
                target="_blank"
                rel="noopener noreferrer"
                className="bp-share-option whatsapp"
                onClick={() =>
                  void trackEvent(
                    business.id,
                    "share_click",
                    { method: "whatsapp" },
                  )
                }
              >
                <span>◉</span>
                <small>WhatsApp</small>
              </a>

              <a
                href={`https://www.facebook.com/sharer/sharer.php?u=${encodedPageUrl}`}
                target="_blank"
                rel="noopener noreferrer"
                className="bp-share-option facebook"
                onClick={() =>
                  void trackEvent(
                    business.id,
                    "share_click",
                    { method: "facebook" },
                  )
                }
              >
                <span>f</span>
                <small>Facebook</small>
              </a>

              <button
                type="button"
                onClick={shareToTikTok}
                className="bp-share-option tiktok"
              >
                <span>♪</span>
                <small>TikTok</small>
              </button>

              <a
                href={`https://twitter.com/intent/tweet?text=${encodedShareText}&url=${encodedPageUrl}`}
                target="_blank"
                rel="noopener noreferrer"
                className="bp-share-option x"
                onClick={() =>
                  void trackEvent(
                    business.id,
                    "share_click",
                    { method: "x" },
                  )
                }
              >
                <span>𝕏</span>
                <small>X</small>
              </a>

              <a
                href={`https://t.me/share/url?url=${encodedPageUrl}&text=${encodedShareText}`}
                target="_blank"
                rel="noopener noreferrer"
                className="bp-share-option telegram"
                onClick={() =>
                  void trackEvent(
                    business.id,
                    "share_click",
                    { method: "telegram" },
                  )
                }
              >
                <span>➤</span>
                <small>Telegram</small>
              </a>

              <a
                href={`mailto:?subject=${encodedShareText}&body=${encodedShareText}%0A${encodedPageUrl}`}
                className="bp-share-option email"
                onClick={() =>
                  void trackEvent(
                    business.id,
                    "share_click",
                    { method: "email" },
                  )
                }
              >
                <span>@</span>
                <small>Email</small>
              </a>

              <button
                type="button"
                onClick={copyLink}
                className="bp-share-option copy"
              >
                <span>⌘</span>
                <small>
                  {copied ? "Copied" : "Copy link"}
                </small>
              </button>
            </div>
          </div>
        )}
      </header>

      <section className="bp-hero">
        <div className="bp-hero-inner">
          <div className="bp-business-heading">
            <div className="bp-logo">
              <Logo
                src={logoUrl}
                name={business.name}
              />
            </div>

            <div className="bp-business-heading-content">
              <div className="bp-name-row">
                <h1>{business.name}</h1>

                {isBusinessVerified(
                  business.verification_status,
                ) && (
                  <span
                    className="bp-verified"
                    title="Verified business"
                    aria-label="Verified business"
                  >
                    <svg
                      viewBox="0 0 24 24"
                      aria-hidden="true"
                    >
                      <path
                        d="M12 2.5l2.1 1.2 2.4-.1 1.1 2.1 2.1 1.1-.1 2.4L20.5 11l.7 2.3-1.5 1.9.1 2.4-2.2 1-1.1 2.1-2.4-.2L12 21.5l-2.1-1.2-2.4.2-1.1-2.1-2.2-1 .1-2.4-1.5-1.9.7-2.3-.7-2.3 1.5-1.8-.1-2.4 2.2-1 1.1-2.1 2.4.1L12 2.5z"
                        fill="currentColor"
                      />

                      <path
                        d="M8.1 12.1l2.5 2.5 5.4-5.4"
                        fill="none"
                        stroke="white"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                  </span>
                )}
              </div>

              <div className="bp-rating-row">
                <StarRating
                  rating={rating.average_rating ?? 0}
                  size="medium"
                />

                <strong>
                  {rating.average_rating
                    ? Number(
                        rating.average_rating,
                      ).toFixed(1)
                    : "0.0"}
                </strong>

                <span>
                  ({rating.review_count ?? 0} reviews)
                </span>
              </div>

              {location && (
                <p className="bp-location">
                  <span>⌖</span>

                  {[
                    location.city,
                    location.state_region,
                    location.country_code,
                  ]
                    .filter(Boolean)
                    .join(", ")}
                </p>
              )}
            </div>
          </div>

          <div className="bp-action-row">
            {whatsappUrl && (
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="bp-action bp-whatsapp"
                onClick={() =>
                  void trackEvent(
                    business.id,
                    "whatsapp_click",
                    { placement: "hero" },
                  )
                }
              >
                <span>◉</span>
                WhatsApp
              </a>
            )}

            {business.phone && (
              <a
                href={`tel:${business.phone}`}
                className="bp-action"
                onClick={() =>
                  void trackEvent(
                    business.id,
                    "phone_click",
                    { placement: "hero" },
                  )
                }
              >
                <span>☎</span>
                Call
              </a>
            )}

            {business.website_url && (
              <a
                href={
                  isValidUrl(business.website_url)
                    ? business.website_url
                    : `https://${business.website_url}`
                }
                target="_blank"
                rel="noopener noreferrer"
                className="bp-action"
                onClick={() =>
                  void trackEvent(
                    business.id,
                    "website_click",
                    { placement: "hero" },
                  )
                }
              >
                <span>↗</span>
                Website
              </a>
            )}

            <button
              type="button"
              onClick={shareBusiness}
              className="bp-action"
            >
              <span>↗</span>
              Share
            </button>
          </div>
        </div>
      </section>

      <div className="bp-container">
        {/* SECTION NAVIGATION */}
        <nav
          className="bp-profile-nav"
          aria-label="Business sections"
        >
          {navigationItems.map((item) => (
            <button
              key={item.id}
              type="button"
              className={
                activeSection === item.id
                  ? "active"
                  : ""
              }
              onClick={() =>
                setActiveSection(item.id)
              }
              aria-current={
                activeSection === item.id
                  ? "page"
                  : undefined
              }
            >
              <span>{item.label}</span>

              {typeof item.count === "number" &&
                item.count > 0 && (
                  <small>{item.count}</small>
                )}
            </button>
          ))}
        </nav>

        {/* ABOUT */}
        {activeSection === "about" && (
          <section className="bp-section bp-active-content">
            <div className="bp-section-heading">
              <h2>About</h2>
            </div>

            <div className="bp-about-content">
              <p>
                {business.description ||
                  `Learn more about ${business.name}.`}
              </p>
            </div>
          </section>
        )}

        {/* PRODUCTS */}
        {activeSection === "products" && (
          <section className="bp-section bp-active-content">
            <div className="bp-section-heading">
              <div>
                <h2>Products</h2>

                <p className="bp-section-subtitle">
                  Products offered by {business.name}
                </p>
              </div>
            </div>

            {products.length > 0 ? (
              <div className="bp-product-grid">
                {products.map((product, index) => {
                  const name =
                    getRowText(product, [
                      "product_name",
                      "name",
                      "title",
                    ]) || "Product";

                  const description =
                    getRowText(product, [
                      "description",
                      "product_description",
                    ]);

                  const imagePath = getMediaPath(product);
                  const imageUrl =
                    getProductMediaUrl(imagePath);

                  const price = getRowText(product, [
                    "price",
                    "display_price",
                    "price_text",
                  ]);

                  return (
                    <article
                      className="bp-product-card"
                      key={
                        getRowText(product, ["id"]) ||
                        `${name}-${index}`
                      }
                    >
                      {imageUrl ? (
                        <div className="bp-product-image-wrap">
                          <img
                            src={imageUrl}
                            alt={name}
                            className="bp-product-image"
                            loading="lazy"
                          />
                        </div>
                      ) : (
                        <div className="bp-product-image-placeholder">
                          <span>{getInitials(name)}</span>
                        </div>
                      )}

                      <div className="bp-product-content">
                        <h3>{name}</h3>

                        {description && (
                          <p>{description}</p>
                        )}

                        {price && (
                          <strong className="bp-product-price">
                            {price}
                          </strong>
                        )}
                      </div>
                    </article>
                  );
                })}
              </div>
            ) : (
              <div className="bp-empty-section">
                <h3>No products available</h3>

                <p>
                  This business has not added any products
                  yet.
                </p>
              </div>
            )}
          </section>
        )}

        {/* SERVICES */}
        {activeSection === "services" && (
          <section className="bp-section bp-active-content">
            <div className="bp-section-heading">
              <div>
                <h2>Services</h2>

                <p className="bp-section-subtitle">
                  Services provided by {business.name}
                </p>
              </div>
            </div>

            {services.length > 0 ? (
              <div className="bp-service-grid">
                {services.map((service, index) => {
                  const name =
                    getRowText(service, [
                      "service_name",
                      "name",
                      "title",
                    ]) || "Service";

                  const description =
                    getRowText(service, [
                      "description",
                      "service_description",
                    ]);

                  const imagePath = getMediaPath(service);
                  const imageUrl =
                    getBusinessMediaUrl(imagePath);

                  return (
                    <article
                      className="bp-service-card"
                      key={
                        getRowText(service, ["id"]) ||
                        `${name}-${index}`
                      }
                    >
                      {imageUrl ? (
                        <div className="bp-service-image-wrap">
                          <img
                            src={imageUrl}
                            alt={name}
                            className="bp-service-image"
                            loading="lazy"
                          />
                        </div>
                      ) : (
                        <div className="bp-service-image-placeholder">
                          <span>{getInitials(name)}</span>
                        </div>
                      )}

                      <div className="bp-service-content">
                        <h3>{name}</h3>

                        {description && (
                          <p>{description}</p>
                        )}
                      </div>
                    </article>
                  );
                })}
              </div>
            ) : (
              <div className="bp-empty-section">
                <h3>No services available</h3>

                <p>
                  This business has not added any services
                  yet.
                </p>
              </div>
            )}
          </section>
        )}

        {/* PROMOTIONS */}
        {activeSection === "promotions" && (
          <section className="bp-section bp-active-content">
            <div className="bp-section-heading">
              <div>
                <h2>Promotions</h2>

                <p className="bp-section-subtitle">
                  Current offers from {business.name}
                </p>
              </div>
            </div>

            {promotions.length > 0 ? (
              <div className="bp-offers">
                {promotions.map((promotion, index) => {
                  const title =
                    getRowText(promotion, [
                      "title",
                      "name",
                      "promotion_name",
                    ]) || "Special offer";

                  const description =
                    getRowText(promotion, [
                      "description",
                      "details",
                      "offer_description",
                    ]);

                  const discount =
                    getRowText(promotion, [
                      "discount",
                      "discount_text",
                      "offer",
                    ]);

                  const imagePath = getMediaPath(promotion);
                  const imageUrl =
                    getBusinessMediaUrl(imagePath);

                  return (
                    <article
                      className="bp-offer"
                      key={
                        getRowText(promotion, ["id"]) ||
                        `${title}-${index}`
                      }
                    >
                      {imageUrl ? (
                        <div className="bp-offer-image-wrap">
                          <img
                            src={imageUrl}
                            alt={title}
                            className="bp-offer-image"
                            loading="lazy"
                          />
                        </div>
                      ) : (
                        <div className="bp-offer-icon">
                          %
                        </div>
                      )}

                      <div className="bp-offer-content">
                        <h3>{title}</h3>

                        {discount && (
                          <strong>{discount}</strong>
                        )}

                        {description && (
                          <p>{description}</p>
                        )}
                      </div>
                    </article>
                  );
                })}
              </div>
            ) : (
              <div className="bp-empty-section">
                <h3>No promotions available</h3>

                <p>
                  This business has no active promotions.
                </p>
              </div>
            )}
          </section>
        )}

        {/* PHOTOS */}
        {activeSection === "photos" && (
          <section className="bp-section bp-active-content">
            <div className="bp-section-heading">
              <div>
                <h2>Photos</h2>

                <p className="bp-section-subtitle">
                  Photos from {business.name}
                </p>
              </div>
            </div>

            {media.length > 0 ? (
              <div className="bp-gallery">
                {media.map((item, index) => {
                  const path = getMediaPath(item);

                  if (!path) return null;

                  const imageUrl =
                    getBusinessMediaUrl(path);

                  if (!imageUrl) return null;

                  return (
                    <a
                      href={imageUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      key={
                        getRowText(item, ["id"]) ||
                        `${path}-${index}`
                      }
                      className="bp-gallery-item"
                      onClick={() =>
                        void trackEvent(
                          business.id,
                          "photo_click",
                        )
                      }
                    >
                      <img
                        src={imageUrl}
                        alt={
                          getRowText(item, [
                            "title",
                            "description",
                          ]) || `${business.name} photo`
                        }
                        loading="lazy"
                      />
                    </a>
                  );
                })}
              </div>
            ) : (
              <div className="bp-empty-section">
                <h3>No photos available</h3>

                <p>
                  This business has not added any photos
                  yet.
                </p>
              </div>
            )}
          </section>
        )}

        {/* CONTACT */}
        {activeSection === "contact" && (
          <section className="bp-section bp-active-content">
            <div className="bp-section-heading">
              <div>
                <h2>Contact</h2>

                <p className="bp-section-subtitle">
                  Contact {business.name}
                </p>
              </div>
            </div>

            <div className="bp-contact-card">
              {address && (
                <div className="bp-contact-item">
                  <span className="bp-contact-icon">
                    ⌖
                  </span>

                  <div>
                    <strong>Address</strong>

                    <p>{address}</p>

                    {mapUrl && (
                      <a
                        href={mapUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="bp-directions"
                        onClick={() =>
                          void trackEvent(
                            business.id,
                            "directions_click",
                            { placement: "contact" },
                          )
                        }
                      >
                        <span className="bp-paper-plane">
                          ➤
                        </span>

                        <span>Get directions</span>
                      </a>
                    )}
                  </div>
                </div>
              )}

              {business.phone && (
                <div className="bp-contact-item">
                  <span className="bp-contact-icon">
                    ☎
                  </span>

                  <div>
                    <strong>Phone</strong>

                    <a
                      href={`tel:${business.phone}`}
                      onClick={() => {
                        void trackEvent(
                          business.id,
                          "phone_click",
                          { placement: "contact" },
                        );

                        void trackEvent(
                          business.id,
                          "contact_click",
                          {
                            method: "phone",
                            placement: "contact",
                          },
                        );
                      }}
                    >
                      {business.phone}
                    </a>
                  </div>
                </div>
              )}

              {business.email && (
                <div className="bp-contact-item">
                  <span className="bp-contact-icon">
                    @
                  </span>

                  <div>
                    <strong>Email</strong>

                    <a
                      href={`mailto:${business.email}`}
                      onClick={() => {
                        void trackEvent(
                          business.id,
                          "email_click",
                          { placement: "contact" },
                        );

                        void trackEvent(
                          business.id,
                          "contact_click",
                          {
                            method: "email",
                            placement: "contact",
                          },
                        );
                      }}
                    >
                      {business.email}
                    </a>
                  </div>
                </div>
              )}

              {business.website_url && (
                <div className="bp-contact-item">
                  <span className="bp-contact-icon">
                    ↗
                  </span>

                  <div>
                    <strong>Website</strong>

                    <a
                      href={
                        isValidUrl(business.website_url)
                          ? business.website_url
                          : `https://${business.website_url}`
                      }
                      target="_blank"
                      rel="noopener noreferrer"
                      onClick={() => {
                        void trackEvent(
                          business.id,
                          "website_click",
                          { placement: "contact" },
                        );

                        void trackEvent(
                          business.id,
                          "contact_click",
                          {
                            method: "website",
                            placement: "contact",
                          },
                        );
                      }}
                    >
                      Visit website
                    </a>
                  </div>
                </div>
              )}

              {whatsappUrl && (
                <a
                  href={whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bp-whatsapp-large"
                  onClick={() => {
                    void trackEvent(
                      business.id,
                      "whatsapp_click",
                      { placement: "contact" },
                    );

                    void trackEvent(
                      business.id,
                      "contact_click",
                      {
                        method: "whatsapp",
                        placement: "contact",
                      },
                    );
                  }}
                >
                  <span>◉</span>
                  Contact on WhatsApp
                </a>
              )}
            </div>
          </section>
        )}

        {/* BUSINESS HOURS */}
        {activeSection === "hours" && (
          <section className="bp-section bp-active-content">
            <div className="bp-section-heading">
              <div>
                <h2>Business Hours</h2>

                <p className="bp-section-subtitle">
                  Opening hours for {business.name}
                </p>
              </div>
            </div>

            <div className="bp-hours">
              {hours.map((item, index) => {
                const rawDay = item.day_of_week;
                const day = getDayName(rawDay);

                const open = getRowText(item, [
                  "open_time",
                  "opening_time",
                  "opens_at",
                ]);

                const close = getRowText(item, [
                  "close_time",
                  "closing_time",
                  "closes_at",
                ]);

                const closedValue = getRowText(item, [
                  "is_closed",
                  "closed",
                ]);

                const closed =
                  closedValue === "true" ||
                  closedValue === "1";

                const twentyFourHours =
                  (open === "00:00:00" ||
                    open === "00:00") &&
                  (close === "23:59:00" ||
                    close === "23:59");

                return (
                  <div
                    className="bp-hours-row"
                    key={
                      getRowText(item, ["id"]) ||
                      `${day}-${index}`
                    }
                  >
                    <span>{day}</span>

                    <strong
                      className={closed ? "closed" : ""}
                    >
                      {closed
                        ? "Closed"
                        : twentyFourHours
                          ? "Open 24 hours"
                          : open && close
                            ? `${formatBusinessTime(
                                open,
                              )} – ${formatBusinessTime(
                                close,
                              )}`
                            : "Hours unavailable"}
                    </strong>
                  </div>
                );
              })}
            </div>
          </section>
        )}

        {/* SOCIAL */}
        {activeSection === "social" && (
          <section className="bp-section bp-active-content">
            <div className="bp-section-heading">
              <div>
                <h2>Follow {business.name}</h2>

                <p className="bp-section-subtitle">
                  Connect with this business online
                </p>
              </div>
            </div>

            <div className="bp-socials">
              {socialLinks.map((social, index) => {
                const url = getRowText(social, [
                  "url",
                  "profile_url",
                  "social_url",
                  "link",
                ]);

                if (!url) return null;

                const platform =
                  getRowText(social, [
                    "platform",
                    "platform_name",
                    "name",
                  ]) || "Social";

                return (
                  <a
                    href={
                      isValidUrl(url)
                        ? url
                        : `https://${url}`
                    }
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bp-social"
                    key={
                      getRowText(social, ["id"]) ||
                      `${platform}-${index}`
                    }
                    onClick={() =>
                      void trackEvent(
                        business.id,
                        "social_click",
                        { platform },
                      )
                    }
                  >
                    {platform}
                  </a>
                );
              })}
            </div>
          </section>
        )}

        {/* REVIEWS */}
        {activeSection === "reviews" && (
          <section className="bp-section bp-reviews-section bp-active-content">
            <div className="bp-section-heading bp-reviews-heading">
              <div>
                <h2>Reviews</h2>

                <p className="bp-section-subtitle">
                  What customers say about {business.name}
                </p>

                <div className="bp-rating-summary">
                  <StarRating
                    rating={rating.average_rating ?? 0}
                    size="large"
                  />

                  <strong>
                    {rating.average_rating
                      ? Number(
                          rating.average_rating,
                        ).toFixed(1)
                      : "0.0"}
                  </strong>

                  <span>
                    {rating.review_count ?? 0} reviews
                  </span>
                </div>
              </div>
            </div>

            <div className="bp-review-form-card">
              <div className="bp-review-form-header">
                <h3>Write a review</h3>

                <p>
                  No account is required. Tell others
                  about your experience.
                </p>
              </div>

              <form onSubmit={submitReview}>
                <div className="bp-form-group">
                  <label htmlFor="reviewer-name">
                    Your name
                  </label>

                  <input
                    id="reviewer-name"
                    type="text"
                    value={reviewerName}
                    onChange={(event) =>
                      setReviewerName(event.target.value)
                    }
                    placeholder="Enter your name"
                    maxLength={100}
                    required
                  />
                </div>

                <div className="bp-form-group">
                  <label>Your rating</label>

                  <div className="bp-rating-input">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        type="button"
                        className={
                          star <= reviewRating
                            ? "selected"
                            : ""
                        }
                        onClick={() =>
                          setReviewRating(star)
                        }
                        aria-label={`${star} star${
                          star === 1 ? "" : "s"
                        }`}
                      >
                        ★
                      </button>
                    ))}
                  </div>
                </div>

                <div className="bp-form-group">
                  <label htmlFor="review-text">
                    Your review
                  </label>

                  <textarea
                    id="review-text"
                    value={reviewText}
                    onChange={(event) =>
                      setReviewText(event.target.value)
                    }
                    placeholder="Share your experience..."
                    maxLength={2000}
                    rows={5}
                  />
                </div>

                <div className="bp-form-group">
                  <label htmlFor="review-picture">
                    Your picture
                    <span> Optional</span>
                  </label>

                  <input
                    id="review-picture"
                    type="file"
                    accept="image/jpeg,image/png,image/webp"
                    onChange={handleReviewImage}
                  />

                  {reviewImagePreview && (
                    <div className="bp-review-image-preview">
                      <img
                        src={reviewImagePreview}
                        alt="Your review picture preview"
                      />
                    </div>
                  )}

                  <small>
                    JPG, PNG or WebP. Maximum 2 MB.
                  </small>
                </div>

                {reviewMessage && (
                  <p className="bp-review-message">
                    {reviewMessage}
                  </p>
                )}

                <button
                  type="submit"
                  className="bp-primary-button"
                  disabled={submittingReview}
                >
                  {submittingReview
                    ? "Submitting..."
                    : "Submit review"}
                </button>
              </form>
            </div>

            {reviews.length > 0 ? (
              <div className="bp-reviews-list">
                {reviews.map((review) => {
                  const avatar = getCustomerAvatarUrl(
                    review.reviewer_avatar_url,
                  );

                  const reviewer =
                    review.reviewer_name || "Customer";

                  return (
                    <article
                      className="bp-review"
                      key={review.id}
                    >
                      <div className="bp-review-top">
                        {avatar ? (
                          <img
                            src={avatar}
                            alt={reviewer}
                            className="bp-review-avatar"
                          />
                        ) : (
                          <div className="bp-review-avatar-fallback">
                            {getInitials(reviewer)}
                          </div>
                        )}

                        <div className="bp-review-author">
                          <strong>{reviewer}</strong>

                          <div className="bp-review-meta">
                            <StarRating
                              rating={review.rating}
                              size="small"
                            />

                            <span>
                              {formatDate(review.created_at)}
                            </span>
                          </div>
                        </div>
                      </div>

                      {review.review_text && (
                        <p className="bp-review-text">
                          {review.review_text}
                        </p>
                      )}
                    </article>
                  );
                })}
              </div>
            ) : (
              <div className="bp-no-reviews">
                <div>★</div>

                <h3>No reviews yet</h3>

                <p>
                  Be the first person to review this
                  business.
                </p>
              </div>
            )}
          </section>
        )}
      </div>

      {whatsappUrl && (
        <a
          href={whatsappUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="bp-floating-whatsapp"
          aria-label="Contact this business on WhatsApp"
          onClick={() =>
            void trackEvent(
              business.id,
              "whatsapp_click",
              { placement: "floating_button" },
            )
          }
        >
          <span>◉</span>

          <strong>WhatsApp</strong>
        </a>
      )}
    </main>
  );
 }
